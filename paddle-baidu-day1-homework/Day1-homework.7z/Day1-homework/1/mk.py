import os
for i in range(100):
	os.makedirs(str(i))
